﻿using Moq;
using Movies.API.Controllers;
using Movies.Business.Interfaces;
using NUnit.Framework;

namespace Movies.API.Tests.AddMovieRating
{
    public class AddMovieRatingBase
    {

        protected Mock<IRatingService> MockRatingService;

        public AddMovieRatingBase()
        {
            MockRatingService = new Mock<IRatingService>();
        }

        [SetUp]
        protected void SetUp()
        {
            
        }

        protected AddMovieRatingController GetController()
        {
            return new AddMovieRatingController(MockRatingService.Object);
        }

    }
}
