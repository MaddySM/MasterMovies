﻿:r Genres.sql
:r Movies.sql
:r Users.sql
:r MovieRatings.sql